from __future__ import annotations

import secrets
from getpass import getpass
from pathlib import Path

from werkzeug.security import generate_password_hash


ROOT = Path(__file__).resolve().parent
ENV_PATH = ROOT / ".env"


def main() -> None:
    if ENV_PATH.exists():
        print(".env already exists. Delete it only when you want to set up a new admin password.")
        return

    password = getpass("Create an admin password: ")
    confirmation = getpass("Type it again: ")
    if password != confirmation:
        print("The passwords did not match. No file was created.")
        return
    if len(password) < 12:
        print("Use at least 12 characters. No file was created.")
        return

    ENV_PATH.write_text(
        "# Keep this file private. Do not upload it to GitHub.\n"
        f"SECRET_KEY={secrets.token_urlsafe(48)}\n"
        f"ADMIN_PASSWORD_HASH={generate_password_hash(password)}\n"
        "# Set this to true after deploying on an HTTPS website.\n"
        "COOKIE_SECURE=false\n",
        encoding="utf-8",
    )
    print("Admin setup complete. Your password is stored only as a hash in .env.")


if __name__ == "__main__":
    main()

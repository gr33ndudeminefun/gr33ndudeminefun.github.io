from __future__ import annotations

import os
import re
import secrets
import sqlite3
from functools import wraps
from pathlib import Path
from urllib.parse import urlparse

from dotenv import load_dotenv
from flask import Flask, g, jsonify, render_template, request, session
from werkzeug.security import check_password_hash


ROOT = Path(__file__).resolve().parent
INSTANCE_DIR = ROOT / "instance"
DATABASE_PATH = INSTANCE_DIR / "minefun.db"

load_dotenv(ROOT / ".env")

app = Flask(__name__)
app.config.update(
    SECRET_KEY=os.getenv("SECRET_KEY") or secrets.token_urlsafe(48),
    SESSION_COOKIE_HTTPONLY=True,
    SESSION_COOKIE_SAMESITE="Lax",
    SESSION_COOKIE_SECURE=os.getenv("COOKIE_SECURE", "false").lower() == "true",
)


def get_db() -> sqlite3.Connection:
    """Return the request's SQLite connection."""
    connection = g.get("db")
    if connection is None:
        INSTANCE_DIR.mkdir(exist_ok=True)
        connection = sqlite3.connect(DATABASE_PATH)
        connection.row_factory = sqlite3.Row
        connection.execute("PRAGMA foreign_keys = ON")
        g.db = connection
    return connection


@app.teardown_appcontext
def close_db(_error: BaseException | None) -> None:
    connection = g.pop("db", None)
    if connection is not None:
        connection.close()


def init_db() -> None:
    INSTANCE_DIR.mkdir(exist_ok=True)
    connection = sqlite3.connect(DATABASE_PATH)
    try:
        connection.execute("PRAGMA foreign_keys = ON")
        connection.executescript(
            """
            CREATE TABLE IF NOT EXISTS levels (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL COLLATE NOCASE UNIQUE,
                publisher TEXT NOT NULL,
                verifier TEXT NOT NULL,
                position INTEGER NOT NULL UNIQUE
            );

            CREATE TABLE IF NOT EXISTS submissions (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                level_id INTEGER NOT NULL,
                verification_url TEXT NOT NULL,
                raw_footage_url TEXT NOT NULL,
                created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (level_id) REFERENCES levels(id) ON DELETE CASCADE
            );
            """
        )
        level_count = connection.execute("SELECT COUNT(*) FROM levels").fetchone()[0]
        if level_count == 0:
            connection.execute(
                "INSERT INTO levels (name, publisher, verifier, position) VALUES (?, ?, ?, ?)",
                ("Test level", "random_player", "pro_player", 1),
            )
        connection.commit()
    finally:
        connection.close()


def clean_text(value: object, field_name: str, max_length: int = 80) -> str:
    if not isinstance(value, str):
        raise ValueError(f"{field_name} is required.")
    cleaned = re.sub(r"\s+", " ", value).strip()
    if not cleaned:
        raise ValueError(f"{field_name} is required.")
    if len(cleaned) > max_length:
        raise ValueError(f"{field_name} must be {max_length} characters or less.")
    return cleaned


def clean_url(value: object, field_name: str) -> str:
    if not isinstance(value, str):
        raise ValueError(f"{field_name} is required.")
    url = value.strip()
    parsed = urlparse(url)
    if parsed.scheme not in {"http", "https"} or not parsed.netloc:
        raise ValueError(f"{field_name} must be a complete http or https URL.")
    if len(url) > 2048:
        raise ValueError(f"{field_name} is too long.")
    return url


def admin_required(view):
    @wraps(view)
    def wrapped(*args, **kwargs):
        if not session.get("is_admin"):
            return jsonify({"error": "Admin login required."}), 401
        return view(*args, **kwargs)

    return wrapped


def csrf_required(view):
    @wraps(view)
    def wrapped(*args, **kwargs):
        supplied_token = request.headers.get("X-CSRF-Token", "")
        expected_token = session.get("csrf_token", "")
        if not expected_token or not secrets.compare_digest(supplied_token, expected_token):
            return jsonify({"error": "Your admin session expired. Please log in again."}), 403
        return view(*args, **kwargs)

    return wrapped


def admin_payload() -> tuple[bool, str | None]:
    return bool(session.get("is_admin")), session.get("csrf_token")


def level_as_json(row: sqlite3.Row) -> dict[str, object]:
    return {
        "id": row["id"],
        "name": row["name"],
        "publisher": row["publisher"],
        "verifier": row["verifier"],
        "position": row["position"],
    }


def reindex_levels(connection: sqlite3.Connection) -> None:
    rows = connection.execute("SELECT id FROM levels ORDER BY position, id").fetchall()
    for position, row in enumerate(rows, start=1):
        connection.execute("UPDATE levels SET position = ? WHERE id = ?", (position, row["id"]))


@app.after_request
def add_security_headers(response):
    response.headers["X-Content-Type-Options"] = "nosniff"
    response.headers["Referrer-Policy"] = "same-origin"
    response.headers["Content-Security-Policy"] = (
        "default-src 'self'; connect-src 'self'; img-src 'self' data:; "
        "style-src 'self'; script-src 'self'; base-uri 'self'; frame-ancestors 'none'"
    )
    if request.path.startswith("/api/"):
        response.headers["Cache-Control"] = "no-store"
    return response


@app.get("/")
def index():
    return render_template("index.html")


@app.get("/api/levels")
def list_levels():
    rows = get_db().execute(
        "SELECT id, name, publisher, verifier, position FROM levels ORDER BY position, id"
    ).fetchall()
    return jsonify({"levels": [level_as_json(row) for row in rows]})


@app.post("/api/submissions")
def create_submission():
    payload = request.get_json(silent=True) or {}
    try:
        level_id = int(payload.get("levelId"))
        verification_url = clean_url(payload.get("verificationUrl"), "Verification URL")
        raw_footage_url = clean_url(payload.get("rawFootageUrl"), "Raw footage URL")
    except (TypeError, ValueError) as error:
        return jsonify({"error": str(error)}), 400

    connection = get_db()
    level = connection.execute("SELECT id FROM levels WHERE id = ?", (level_id,)).fetchone()
    if level is None:
        return jsonify({"error": "That level no longer exists."}), 404

    connection.execute(
        """
        INSERT INTO submissions (level_id, verification_url, raw_footage_url)
        VALUES (?, ?, ?)
        """,
        (level_id, verification_url, raw_footage_url),
    )
    connection.commit()
    return jsonify({"message": "Verification submitted."}), 201


@app.post("/api/login")
def login():
    password_hash = os.getenv("ADMIN_PASSWORD_HASH", "")
    if not password_hash:
        return jsonify({"error": "The server admin password has not been set up yet."}), 503

    payload = request.get_json(silent=True) or {}
    password = payload.get("password", "")
    if not isinstance(password, str) or not check_password_hash(password_hash, password):
        return jsonify({"error": "Incorrect password."}), 401

    session.clear()
    session["is_admin"] = True
    session["csrf_token"] = secrets.token_urlsafe(32)
    return jsonify({"message": "Admin login successful."})


@app.post("/api/logout")
@admin_required
@csrf_required
def logout():
    session.clear()
    return jsonify({"message": "Logged out."})


@app.get("/api/session")
def get_session():
    is_admin, csrf_token = admin_payload()
    return jsonify({"isAdmin": is_admin, "csrfToken": csrf_token if is_admin else None})


@app.get("/api/admin/submissions")
@admin_required
def list_submissions():
    rows = get_db().execute(
        """
        SELECT submissions.id, submissions.verification_url, submissions.raw_footage_url,
               submissions.created_at, levels.name AS level_name
        FROM submissions
        JOIN levels ON levels.id = submissions.level_id
        ORDER BY submissions.id DESC
        """
    ).fetchall()
    return jsonify(
        {
            "submissions": [
                {
                    "id": row["id"],
                    "levelName": row["level_name"],
                    "verificationUrl": row["verification_url"],
                    "rawFootageUrl": row["raw_footage_url"],
                    "createdAt": row["created_at"],
                }
                for row in rows
            ]
        }
    )


@app.post("/api/admin/levels")
@admin_required
@csrf_required
def add_level():
    payload = request.get_json(silent=True) or {}
    try:
        name = clean_text(payload.get("name"), "Level name")
        publisher = clean_text(payload.get("publisher"), "Publisher name")
        verifier = clean_text(payload.get("verifier"), "Verifier name")
    except ValueError as error:
        return jsonify({"error": str(error)}), 400

    connection = get_db()
    next_position = connection.execute("SELECT COALESCE(MAX(position), 0) + 1 FROM levels").fetchone()[0]
    try:
        connection.execute(
            "INSERT INTO levels (name, publisher, verifier, position) VALUES (?, ?, ?, ?)",
            (name, publisher, verifier, next_position),
        )
        connection.commit()
    except sqlite3.IntegrityError:
        return jsonify({"error": "A level with that name already exists."}), 409
    return jsonify({"message": "Level added."}), 201


@app.delete("/api/admin/levels/<int:level_id>")
@admin_required
@csrf_required
def delete_level(level_id: int):
    connection = get_db()
    deleted = connection.execute("DELETE FROM levels WHERE id = ?", (level_id,)).rowcount
    if deleted == 0:
        return jsonify({"error": "That level no longer exists."}), 404
    reindex_levels(connection)
    connection.commit()
    return jsonify({"message": "Level deleted."})


if __name__ == "__main__":
    init_db()
    app.run(host="127.0.0.1", port=5000, debug=False)
else:
    init_db()

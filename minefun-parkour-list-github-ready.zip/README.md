# Minefun.io Top Parkour List

This is a Flask website with a server-side admin login, a shared SQLite database, and a JavaScript interface.

## Run it locally

```powershell
py -m venv .venv
.\.venv\Scripts\Activate.ps1
pip install -r requirements.txt
python setup_admin.py
python app.py
```

Open `http://127.0.0.1:5000` in your browser.

`setup_admin.py` asks for the password privately and stores only a password hash in `.env`. Do not upload `.env` to a public repository. When deploying behind HTTPS, set `COOKIE_SECURE=true` in `.env`.

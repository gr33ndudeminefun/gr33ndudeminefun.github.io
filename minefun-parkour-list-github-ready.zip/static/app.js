const levelList = document.querySelector("#levelList");
const levelCount = document.querySelector("#levelCount");
const adminButton = document.querySelector("#adminButton");
const adminPanel = document.querySelector("#adminPanel");
const adminDialog = document.querySelector("#adminDialog");
const closeDialogButton = document.querySelector("#closeDialogButton");
const loginForm = document.querySelector("#loginForm");
const passwordInput = document.querySelector("#passwordInput");
const loginMessage = document.querySelector("#loginMessage");
const addLevelForm = document.querySelector("#addLevelForm");
const deleteLevelForm = document.querySelector("#deleteLevelForm");
const adminSubmissionList = document.querySelector("#adminSubmissionList");
const toast = document.querySelector("#toast");

let levels = [];
let isAdmin = false;
let csrfToken = null;
let toastTimer = null;

function escapeHtml(value) {
  return String(value)
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#039;");
}

async function requestJson(url, options = {}) {
  const headers = { ...(options.headers || {}) };
  if (options.body) {
    headers["Content-Type"] = "application/json";
  }
  const response = await fetch(url, { ...options, headers });
  const payload = await response.json().catch(() => ({}));
  if (!response.ok) {
    throw new Error(payload.error || "Something went wrong.");
  }
  return payload;
}

function showToast(message) {
  window.clearTimeout(toastTimer);
  toast.textContent = message;
  toast.classList.add("is-visible");
  toastTimer = window.setTimeout(() => toast.classList.remove("is-visible"), 3200);
}

function renderLevels() {
  levelCount.textContent = levels.length === 1 ? "1 level" : `${levels.length} levels`;
  levelList.innerHTML = levels
    .map(
      (level) => `
        <article class="level-card">
          <div class="rank-tile" aria-hidden="true"><span>#${level.position}</span></div>
          <div class="level-content">
            <h2>#${level.position} - ${escapeHtml(level.name)}</h2>
            <div class="level-details">
              <p><strong>Publisher:</strong> ${escapeHtml(level.publisher)}</p>
              <p><strong>Verifier:</strong> ${escapeHtml(level.verifier)}</p>
            </div>
            <form class="submit-form" data-submit-form data-level-id="${level.id}">
              <label>
                Submit your verification here:
                <input name="verificationUrl" type="url" placeholder="Video URL" required>
              </label>
              <label>
                Raw footage:
                <input name="rawFootageUrl" type="url" placeholder="Video URL" required>
              </label>
              <button type="submit">Submit</button>
            </form>
          </div>
        </article>
      `,
    )
    .join("");
}

function renderAdminSubmissions(submissions) {
  if (!submissions.length) {
    adminSubmissionList.innerHTML = '<p class="empty-submissions">No submitted verifications yet.</p>';
    return;
  }
  adminSubmissionList.innerHTML = submissions
    .map(
      (submission) => `
        <div class="submission-row">
          <strong>${escapeHtml(submission.levelName)}</strong>
          <a href="${escapeHtml(submission.verificationUrl)}" target="_blank" rel="noopener noreferrer">Verification: ${escapeHtml(submission.verificationUrl)}</a>
          <a href="${escapeHtml(submission.rawFootageUrl)}" target="_blank" rel="noopener noreferrer">Raw footage: ${escapeHtml(submission.rawFootageUrl)}</a>
        </div>
      `,
    )
    .join("");
}

function updateAdminView() {
  adminPanel.hidden = !isAdmin;
  adminButton.textContent = isAdmin ? "Log out" : "Admin login";
}

async function loadLevels() {
  const payload = await requestJson("/api/levels");
  levels = payload.levels;
  renderLevels();
}

async function loadAdminSubmissions() {
  if (!isAdmin) {
    return;
  }
  const payload = await requestJson("/api/admin/submissions");
  renderAdminSubmissions(payload.submissions);
}

async function loadSession() {
  const payload = await requestJson("/api/session");
  isAdmin = payload.isAdmin;
  csrfToken = payload.csrfToken;
  updateAdminView();
}

levelList.addEventListener("submit", async (event) => {
  const form = event.target.closest("[data-submit-form]");
  if (!form) {
    return;
  }
  event.preventDefault();
  const formData = new FormData(form);
  const button = form.querySelector("button");
  button.disabled = true;
  try {
    const payload = await requestJson("/api/submissions", {
      method: "POST",
      body: JSON.stringify({
        levelId: Number(form.dataset.levelId),
        verificationUrl: formData.get("verificationUrl"),
        rawFootageUrl: formData.get("rawFootageUrl"),
      }),
    });
    form.reset();
    showToast(payload.message);
    await loadAdminSubmissions();
  } catch (error) {
    showToast(error.message);
  } finally {
    button.disabled = false;
  }
});

adminButton.addEventListener("click", async () => {
  if (!isAdmin) {
    loginMessage.textContent = "";
    passwordInput.value = "";
    adminDialog.showModal();
    passwordInput.focus();
    return;
  }
  try {
    const payload = await requestJson("/api/logout", {
      method: "POST",
      headers: { "X-CSRF-Token": csrfToken },
    });
    isAdmin = false;
    csrfToken = null;
    updateAdminView();
    showToast(payload.message);
  } catch (error) {
    showToast(error.message);
  }
});

closeDialogButton.addEventListener("click", () => adminDialog.close());

loginForm.addEventListener("submit", async (event) => {
  event.preventDefault();
  loginMessage.textContent = "";
  const submitButton = loginForm.querySelector("button[type='submit']");
  submitButton.disabled = true;
  try {
    const payload = await requestJson("/api/login", {
      method: "POST",
      body: JSON.stringify({ password: passwordInput.value }),
    });
    await loadSession();
    await loadAdminSubmissions();
    adminDialog.close();
    showToast(payload.message);
  } catch (error) {
    loginMessage.textContent = error.message;
  } finally {
    submitButton.disabled = false;
  }
});

addLevelForm.addEventListener("submit", async (event) => {
  event.preventDefault();
  const formData = new FormData(addLevelForm);
  try {
    const payload = await requestJson("/api/admin/levels", {
      method: "POST",
      headers: { "X-CSRF-Token": csrfToken },
      body: JSON.stringify({
        name: formData.get("name"),
        publisher: formData.get("publisher"),
        verifier: formData.get("verifier"),
      }),
    });
    addLevelForm.reset();
    await loadLevels();
    showToast(payload.message);
  } catch (error) {
    showToast(error.message);
  }
});

deleteLevelForm.addEventListener("submit", async (event) => {
  event.preventDefault();
  const formData = new FormData(deleteLevelForm);
  const name = String(formData.get("name")).trim().toLocaleLowerCase();
  const level = levels.find((item) => item.name.toLocaleLowerCase() === name);
  if (!level) {
    showToast("No level with that name exists.");
    return;
  }
  try {
    const payload = await requestJson(`/api/admin/levels/${level.id}`, {
      method: "DELETE",
      headers: { "X-CSRF-Token": csrfToken },
    });
    deleteLevelForm.reset();
    await loadLevels();
    await loadAdminSubmissions();
    showToast(payload.message);
  } catch (error) {
    showToast(error.message);
  }
});

Promise.all([loadSession(), loadLevels()])
  .then(loadAdminSubmissions)
  .catch((error) => {
    levelCount.textContent = "Could not load levels";
    showToast(error.message);
  });
